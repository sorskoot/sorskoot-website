const path = require('path');

module.exports = {
  entry: './BasicTemplate-bundle.js',
  output: {
    filename: 'BasicTemplate-bundle.js',
    path: path.resolve(__dirname, 'deploy'),
  },
};