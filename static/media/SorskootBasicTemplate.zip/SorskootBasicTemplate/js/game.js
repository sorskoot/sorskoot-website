import {State} from './classes/gameState';

WL.registerComponent('game', {
    playerObject: { type: WL.Type.Object }
}, {
    init: function() {        
        WL.onXRSessionStart.push(() => BasicTemplate.gameState.isInVR = true);
        WL.onXRSessionEnd.push(() => BasicTemplate.gameState.isInVR = false);
        WL.onXRSessionStart.push(() => {
            BasicTemplate.soundFxPlayer.initAudio();
            BasicTemplate.musicPlayer.initAudio();
        });
    },
    start: function() {
        BasicTemplate.gameState.state = State.Title;
    },
    update: function(dt) {
  
    },
});
